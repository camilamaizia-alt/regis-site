Coloque seu arquivo de logotipo nesta pasta com o nome: logo-regis.png
Depois dê 2 cliques em index.html para abrir no navegador.
